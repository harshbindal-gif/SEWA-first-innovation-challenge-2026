import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, discovery, planner
from .models import Requirements
from .pipeline import MISSIONS, Mission, get_mission, run_mission
from .purchase_order import render_po

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
app = FastAPI(title="Ghost Operator")
_tasks: set[asyncio.Task] = set()


class PlanIn(BaseModel):
    objective: str


class VendorIn(BaseModel):
    key: str = Field(pattern=r"^[a-z0-9]{1,40}$")
    name: str = Field(max_length=80)
    url: str = Field(pattern=r"^https://[^\s]{4,500}$")
    hint: str = ""
    discovered: bool = True


class MissionIn(BaseModel):
    objective: str
    requirements: Requirements
    vendor_keys: list[str]
    extra_vendors: list[VendorIn] = []
    planner: str = "user-edited"


class DecisionIn(BaseModel):
    decision: Literal["approve", "reject"]
    offer_id: Optional[str] = None
    approver: str = ""
    note: str = ""


@app.get("/api/info")
def info():
    domains = config.load_domains()
    return {"mode": config.effective_mode(), "concurrency": config.TINYFISH_CONCURRENCY,
            "model": config.ANTHROPIC_MODEL,
            "domains": {k: {"label": d["label"], "vendors": d["vendors"]} for k, d in domains.items()}}


@app.post("/api/plan")
async def plan(body: PlanIn):
    domains = config.load_domains()
    req, used = await asyncio.to_thread(planner.plan, body.objective, domains)
    known = [dict(v) for v in domains[req.domain]["vendors"]]
    found = await discovery.discover(req, known, config.effective_mode())
    for v in known + found["vendors"]:  # in replay mode only vendors with a recorded agent run can be dispatched
        v["recorded"] = config.effective_mode() == "live" or (config.REPLAY_DIR / req.domain / f"{v['key']}.json").exists()
    return {"requirements": req.model_dump(), "planner": used, "vendors": known, "discovery": found}


@app.post("/api/missions")
async def create_mission(body: MissionIn):
    domains = config.load_domains()
    if body.requirements.domain not in domains:
        raise HTTPException(400, "unknown domain")
    vendors = [v for v in domains[body.requirements.domain]["vendors"] if v["key"] in body.vendor_keys]
    known = {v["key"] for v in vendors}
    vendors += [v.model_dump() for v in body.extra_vendors if v.key not in known][:4]
    if not vendors:
        raise HTTPException(400, "pick at least one vendor")
    m = Mission(body.requirements, vendors, body.objective, body.planner)
    MISSIONS[m.id] = m
    t = asyncio.create_task(run_mission(m))
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)
    return {"id": m.id}


def _get(mid: str) -> Mission:
    m = get_mission(mid)
    if not m:
        raise HTTPException(404, "mission not found")
    return m


@app.get("/api/missions/{mid}")
def mission_detail(mid: str):
    return _get(mid).snapshot()


@app.get("/api/missions/{mid}/events")
async def events(mid: str, since: int = 0):
    m = _get(mid)

    async def gen():
        seq = since
        while True:
            while seq < len(m.events):
                yield f"data: {json.dumps(m.events[seq])}\n\n"
                seq += 1
            if m.status in ("awaiting_approval", "approved", "rejected", "failed") and seq >= len(m.events):
                yield "event: end\ndata: {}\n\n"
                return
            if not await m.wait_for(seq):
                yield ": keepalive\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})


@app.post("/api/missions/{mid}/decision")
def decide(mid: str, body: DecisionIn):
    m = _get(mid)
    if not m.report:
        raise HTTPException(409, "mission has no recommendation yet")
    ids = {o["id"] for o in m.report["offers"]}
    offer_id = body.offer_id or m.report["recommended_offer_id"]
    if offer_id not in ids:
        raise HTTPException(400, "unknown offer")
    m.decision = {**body.model_dump(), "offer_id": offer_id, "at": datetime.now(timezone.utc).isoformat()}
    m.status = "approved" if body.decision == "approve" else "rejected"
    m.save()
    return m.snapshot()


@app.get("/missions/{mid}/po", response_class=HTMLResponse)
def po(mid: str):
    return render_po(_get(mid))


app.mount("/", StaticFiles(directory=config.FRONTEND_DIR, html=True), name="frontend")
